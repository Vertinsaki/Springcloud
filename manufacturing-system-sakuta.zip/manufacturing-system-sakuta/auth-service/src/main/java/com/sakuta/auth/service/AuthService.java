package com.sakuta.auth.service;

import com.sakuta.auth.model.JwtResponse;
import com.sakuta.auth.model.User;

public interface AuthService {
    void register(User user);
    JwtResponse login(String username, String password);
}
