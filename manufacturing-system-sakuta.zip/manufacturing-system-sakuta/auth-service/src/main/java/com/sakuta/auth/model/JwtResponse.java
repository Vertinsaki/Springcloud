package com.sakuta.auth.model;

import lombok.Data;

@Data
public class JwtResponse {
    private String token;
    private String username;
}
