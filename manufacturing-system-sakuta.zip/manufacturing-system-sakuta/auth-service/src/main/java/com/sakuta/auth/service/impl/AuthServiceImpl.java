package com.sakuta.auth.service.impl;

import com.sakuta.auth.mapper.UserMapper;
import com.sakuta.auth.model.JwtResponse;
import com.sakuta.auth.model.User;
import com.sakuta.auth.service.AuthService;
import com.sakuta.auth.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserMapper userMapper;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public void register(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword())); // 加密密码
        userMapper.insertUser(user);
    }

    @Override
    public JwtResponse login(String username, String password) {
        User user = userMapper.getUserByUsername(username);
        if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Invalid username or password");
        }
        String token = JwtUtils.generateToken(username);
        JwtResponse response = new JwtResponse();
        response.setToken(token);
        response.setUsername(username);
        return response;
    }
}
