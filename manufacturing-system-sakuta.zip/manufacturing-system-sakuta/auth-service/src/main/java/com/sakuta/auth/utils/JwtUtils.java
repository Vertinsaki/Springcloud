package com.sakuta.auth.utils;

import io.jsonwebtoken.*;
import java.util.Date;

public class JwtUtils {

    // 使用字符串作为密钥
    private static final String SECRET = "thisisaverylongsecretkeythatmustbe32byteslong!!";
    private static final long EXPIRATION_TIME = 86400000; // 1 天

    // 生成 JWT Token
    public static String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                // 使用 SECRET 字符串作为密钥
                .signWith(SignatureAlgorithm.HS256, SECRET)
                .compact();
    }

    // 校验 JWT Token
    public static boolean validateToken(String token) {
        try {
            // 使用 SECRET 字符串作为密钥
            Jwts.parserBuilder()
                    .setSigningKey(SECRET)  // 设置密钥
                    .build()
                    .parseClaimsJws(token);  // 解析 Token
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false;  // 校验失败
        }
    }
}
