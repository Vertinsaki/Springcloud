package com.sakuta.auth.controller;

import com.sakuta.auth.model.JwtResponse;
import com.sakuta.auth.model.User;
import com.sakuta.auth.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public String register(@RequestBody User user) {
        authService.register(user);
        return "User registered successfully!";
    }

    @PostMapping("/login")
    public JwtResponse login(@RequestParam String username, @RequestParam String password) {
        return authService.login(username, password);
    }
}
