package com.sakuta.inventory.controller;

import com.sakuta.inventory.model.Inventory;
import com.sakuta.inventory.model.Result;
import com.sakuta.inventory.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/inventories")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;


    @PostMapping
    public Result addInventory(@RequestBody Inventory inventory) {
        inventoryService.addInventory(inventory);
        return Result.success();
    }


    @PutMapping("/{id}")
    public Result updateInventory(@PathVariable Integer id, @RequestBody Inventory inventory) {
        inventoryService.updateInventory(id, inventory);
        return Result.success();
    }


    @GetMapping("/{id}")
    public Result getInventory(@PathVariable Integer id) {
        Inventory inventory = inventoryService.getInventoryById(id);
        return Result.success(inventory);
    }


    @GetMapping
    public Result getAllInventories() {
        List<Inventory> inventories = inventoryService.getAllInventories();
        return Result.success(inventories);
    }


    @DeleteMapping("/{id}")
    public Result deleteInventory(@PathVariable Integer id) {
        inventoryService.deleteInventory(id);
        return Result.success();
    }

    @GetMapping("/check")
    public boolean checkInventoryAvailability() {
        return inventoryService.checkInventoryAvailability();
    }
}
