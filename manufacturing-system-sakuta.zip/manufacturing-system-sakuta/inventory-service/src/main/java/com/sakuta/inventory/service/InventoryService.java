package com.sakuta.inventory.service;

import com.sakuta.inventory.model.Inventory;

import java.util.List;

public interface InventoryService {

    void addInventory(Inventory inventory);

    void updateInventory(Integer inventoryId, Inventory inventory);

    Inventory getInventoryById(Integer inventoryId);

    List<Inventory> getAllInventories();

    void deleteInventory(Integer inventoryId);

    boolean checkInventoryAvailability();


}
