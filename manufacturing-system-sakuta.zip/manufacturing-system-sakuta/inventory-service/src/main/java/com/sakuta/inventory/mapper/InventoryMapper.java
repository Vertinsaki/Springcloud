package com.sakuta.inventory.mapper;

import com.sakuta.inventory.model.Inventory;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface InventoryMapper {

    @Insert("INSERT INTO inventories (product_name, quantity, last_updated) " +
            "VALUES (#{productName}, #{quantity}, #{lastUpdated})")
    @Options(useGeneratedKeys = true, keyProperty = "inventoryId")
    void insertInventory(Inventory inventory);

    @Update("UPDATE inventories SET quantity = #{quantity}, last_updated = #{lastUpdated} WHERE inventory_id = #{inventoryId}")
    void updateInventory(Inventory inventory);

    @Select("SELECT * FROM inventories WHERE inventory_id = #{inventoryId}")
    Inventory selectInventoryById(Integer inventoryId);

    @Select("SELECT * FROM inventories")
    List<Inventory> selectAllInventories();

    @Delete("DELETE FROM inventories WHERE inventory_id = #{inventoryId}")
    void deleteInventory(Integer inventoryId);
}
