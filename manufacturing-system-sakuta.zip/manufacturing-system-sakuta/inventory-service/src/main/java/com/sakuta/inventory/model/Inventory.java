package com.sakuta.inventory.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Inventory {
    private Integer inventoryId;
    private String productName;
    private Integer quantity;
    private LocalDateTime lastUpdated;
}
