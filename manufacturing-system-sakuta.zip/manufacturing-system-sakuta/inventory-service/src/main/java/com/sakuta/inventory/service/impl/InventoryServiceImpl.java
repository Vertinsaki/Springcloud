package com.sakuta.inventory.service.impl;

import com.sakuta.inventory.model.Inventory;
import com.sakuta.inventory.mapper.InventoryMapper;
import com.sakuta.inventory.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryServiceImpl implements InventoryService {

    private final InventoryMapper inventoryMapper;

    @Autowired
    public InventoryServiceImpl(InventoryMapper inventoryMapper) {

        this.inventoryMapper = inventoryMapper;
    }

    @Override
    public void addInventory(Inventory inventory) {
        inventoryMapper.insertInventory(inventory);
    }

    @Override
    public void updateInventory(Integer inventoryId, Inventory inventory) {
        inventory.setInventoryId(inventoryId);
        inventoryMapper.updateInventory(inventory);
    }

    @Override
    public Inventory getInventoryById(Integer inventoryId) {
        return inventoryMapper.selectInventoryById(inventoryId);
    }

    @Override
    public List<Inventory> getAllInventories() {
        return inventoryMapper.selectAllInventories();
    }

    @Override
    public void deleteInventory(Integer inventoryId) {
        inventoryMapper.deleteInventory(inventoryId);
    }

    @Override
    public boolean checkInventoryAvailability() {
        List<Inventory> inventories = inventoryMapper.selectAllInventories();  // 获取所有库存


        for (Inventory inventory : inventories) {
            if (inventory.getQuantity() <= 100) {
                return false;
            }
        }
        return true;
    }
}
