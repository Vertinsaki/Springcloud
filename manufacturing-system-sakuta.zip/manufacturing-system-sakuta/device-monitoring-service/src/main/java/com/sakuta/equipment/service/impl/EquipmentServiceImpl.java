package com.sakuta.equipment.service.impl;

import com.sakuta.equipment.model.Equipment;
import com.sakuta.equipment.mapper.EquipmentMapper;
import com.sakuta.equipment.service.EquipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EquipmentServiceImpl implements EquipmentService {

    private final EquipmentMapper equipmentMapper;

    @Autowired
    public EquipmentServiceImpl(EquipmentMapper equipmentMapper) {
        this.equipmentMapper = equipmentMapper;
    }

    @Override
    public void addEquipment(Equipment equipment) {
        equipmentMapper.insertEquipment(equipment);
    }

    @Override
    public void updateEquipment(Integer equipmentId, Equipment equipment) {
        equipment.setEquipmentId(equipmentId);
        equipmentMapper.updateEquipment(equipment);
    }

    @Override
    public Equipment getEquipmentById(Integer equipmentId) {
        return equipmentMapper.selectEquipmentById(equipmentId);
    }

    @Override
    public List<Equipment> getAllEquipment() {
        return equipmentMapper.selectAllEquipment();
    }

    @Override
    public void deleteEquipment(Integer equipmentId) {
        equipmentMapper.deleteEquipment(equipmentId);
    }

    @Override
    public boolean checkEquipmentStatus() {
        List<Equipment> equipmentList = equipmentMapper.selectAllEquipment();

        for (Equipment equipment : equipmentList) {
            if (!"normal".equals(equipment.getStatus())) {
                return false;
            }
        }
        return true;
    }
}
