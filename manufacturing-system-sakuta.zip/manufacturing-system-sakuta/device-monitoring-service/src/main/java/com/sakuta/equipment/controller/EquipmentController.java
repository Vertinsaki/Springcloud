package com.sakuta.equipment.controller;

import com.sakuta.equipment.model.Equipment;
import com.sakuta.equipment.model.Result;
import com.sakuta.equipment.service.EquipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/equipment")
public class EquipmentController {

    @Autowired
    private EquipmentService equipmentService;


    @PostMapping
    public Result addEquipment(@RequestBody Equipment equipment) {
        equipmentService.addEquipment(equipment);
        return Result.success();
    }


    @PutMapping("/{id}")
    public Result updateEquipment(@PathVariable Integer id, @RequestBody Equipment equipment) {
        equipmentService.updateEquipment(id, equipment);
        return Result.success();
    }


    @GetMapping("/{id}")
    public Result getEquipment(@PathVariable Integer id) {
        Equipment equipment = equipmentService.getEquipmentById(id);
        return Result.success(equipment);
    }


    @GetMapping
    public Result getAllEquipment() {
        List<Equipment> equipmentList = equipmentService.getAllEquipment();
        return Result.success(equipmentList);
    }


    @DeleteMapping("/{id}")
    public Result deleteEquipment(@PathVariable Integer id) {
        equipmentService.deleteEquipment(id);
        return Result.success();
    }

    @GetMapping("/status")
    public boolean checkEquipmentStatus() {
        return equipmentService.checkEquipmentStatus();
    }
}
