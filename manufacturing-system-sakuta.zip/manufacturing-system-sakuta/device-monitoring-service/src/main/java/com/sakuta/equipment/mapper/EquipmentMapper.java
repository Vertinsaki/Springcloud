package com.sakuta.equipment.mapper;

import com.sakuta.equipment.model.Equipment;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface EquipmentMapper {

    @Insert("INSERT INTO equipment_status (equipment_name, status, last_checked) " +
            "VALUES (#{equipmentName}, #{status}, #{lastChecked})")
    @Options(useGeneratedKeys = true, keyProperty = "equipmentId")
    void insertEquipment(Equipment equipment);

    @Update("UPDATE equipment_status SET status = #{status}, last_checked = #{lastChecked} " +
            "WHERE equipment_id = #{equipmentId}")
    void updateEquipment(Equipment equipment);

    @Select("SELECT * FROM equipment_status WHERE equipment_id = #{equipmentId}")
    Equipment selectEquipmentById(Integer equipmentId);

    @Select("SELECT * FROM equipment_status")
    List<Equipment> selectAllEquipment();

    @Delete("DELETE FROM equipment_status WHERE equipment_id = #{equipmentId}")
    void deleteEquipment(Integer equipmentId);
}
