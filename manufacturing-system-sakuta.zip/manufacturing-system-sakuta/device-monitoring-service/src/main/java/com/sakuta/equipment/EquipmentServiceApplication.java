package com.sakuta.equipment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class EquipmentServiceApplication {

    public static void main(String[] args) {

        SpringApplication.run(EquipmentServiceApplication.class, args);
    }

}
