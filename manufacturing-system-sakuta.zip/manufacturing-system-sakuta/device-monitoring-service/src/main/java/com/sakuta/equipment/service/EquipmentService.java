package com.sakuta.equipment.service;

import com.sakuta.equipment.model.Equipment;

import java.util.List;

public interface EquipmentService {

    void addEquipment(Equipment equipment);

    void updateEquipment(Integer equipmentId, Equipment equipment);

    Equipment getEquipmentById(Integer equipmentId);

    List<Equipment> getAllEquipment();

    void deleteEquipment(Integer equipmentId);

    boolean checkEquipmentStatus();
}
