package com.sakuta.equipment.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Equipment {
    private Integer equipmentId;  // 设备ID
    private String equipmentName; // 设备名称
    private String status;        // 设备状态（normal, maintenance, fault）
    private LocalDateTime lastChecked; // 上次检查时间
}
