package com.sakuta.gateway.filter;

import com.sakuta.gateway.utils.JwtUtils;  // 导入 JwtUtils 工具类
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
public class JwtFilter implements GlobalFilter {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String path = exchange.getRequest().getURI().getPath();


        if (path.startsWith("/auth")) {
            return chain.filter(exchange);
        }


        String token = null;
        List<String> heads = exchange.getRequest().getHeaders().get("Authorization");
        if (heads != null && !heads.isEmpty()) {

            token = heads.get(0).replace("Bearer ", "").trim();
        }


        if (token == null || !JwtUtils.validateToken(token)) {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        return chain.filter(exchange);
    }
}
