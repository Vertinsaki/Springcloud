package com.sakuta.production.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "inventory-service", url = "http://localhost:9093")
public interface InventoryClient {

    @GetMapping("/inventories/check")
    boolean checkInventoryAvailability();
}
