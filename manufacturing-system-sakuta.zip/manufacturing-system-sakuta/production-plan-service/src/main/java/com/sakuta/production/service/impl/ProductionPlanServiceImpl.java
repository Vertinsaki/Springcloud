package com.sakuta.production.service.impl;

import com.sakuta.production.client.OrderClient;
import com.sakuta.production.client.InventoryClient;
import com.sakuta.production.client.EquipmentClient;
import com.sakuta.production.model.Order;
import com.sakuta.production.model.ProductionPlan;
import com.sakuta.production.mapper.ProductionPlanMapper;
import com.sakuta.production.service.ProductionPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ProductionPlanServiceImpl implements ProductionPlanService {

    @Autowired
    private OrderClient orderClient;

    @Autowired
    private InventoryClient inventoryClient;

    @Autowired
    private EquipmentClient equipmentClient;

    @Autowired
    private ProductionPlanMapper productionPlanMapper;



    @Override
    public boolean checkProductionReadiness() {
        // Step 1: 检查库存是否满足条件
        boolean isInventoryReady = inventoryClient.checkInventoryAvailability();  // 查询库存
        if (!isInventoryReady) {
            return false;  // 库存不满足条件，不能开工
        }

        // Step 2: 检查设备状态是否正常
        boolean isEquipmentReady = equipmentClient.checkEquipmentStatus();  // 查询设备状态
        if (!isEquipmentReady) {
            return false;  // 设备不满足条件，不能开工
        }

        return true;  // 库存和设备都满足条件，可以开工
    }

    @Override
    public void createPlansForAllOrders() {

        List<Order> allOrders = orderClient.getAllOrders();


        allOrders.sort((o1, o2) -> Long.compare(o2.getOrderAmount(), o1.getOrderAmount()));


        int priority = 1;
        for (Order order : allOrders) {
            if (checkProductionReadiness()) {
                ProductionPlan plan = new ProductionPlan();
                plan.setOrderId(order.getOrderId());
                plan.setPriority(priority);
                plan.setStatus("pending");
                plan.setPlanDate(LocalDateTime.now().plusHours(6));
                productionPlanMapper.insertProductionPlan(plan);
                priority++;
            }
        }
    }

    @Override
    public List<ProductionPlan> getAllProductionPlans() {
        return productionPlanMapper.selectAllPlans();
    }

    @Override
    public ProductionPlan getProductionPlanByOrderId(Long orderId) {
        List<ProductionPlan> plans = productionPlanMapper.selectPlansByOrderId(orderId);
        return plans.isEmpty() ? null : plans.get(0);
    }

    @Override
    public void updateProductionPlanStatus(Integer planId, String status) {
        productionPlanMapper.updatePlanStatus(planId, status);
    }

    @Override
    public void deleteProductionPlan(Integer planId) {
        productionPlanMapper.deleteProductionPlan(planId);
    }
}
