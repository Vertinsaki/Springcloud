package com.sakuta.production.controller;

import com.sakuta.production.model.ProductionPlan;
import com.sakuta.production.model.Result;
import com.sakuta.production.service.ProductionPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/production-plans")
public class ProductionPlanController {

    @Autowired
    private ProductionPlanService productionPlanService;


    @GetMapping("/check-readiness")
    public Result checkProductionReadiness() {
        boolean isReady = productionPlanService.checkProductionReadiness();  // 检查库存和设备状态
        if (isReady) {
            return Result.success("Production is ready to start.");
        } else {
            return Result.error("Production cannot start due to insufficient inventory or equipment issues.");
        }
    }


    @PostMapping("/create-all")
    public Result createAllProductionPlans() {
        boolean isReady = productionPlanService.checkProductionReadiness();  // 检查库存和设备状态
        if (isReady) {
            productionPlanService.createPlansForAllOrders();  // 创建生产计划
            return Result.success("All production plans have been created successfully.");
        } else {
            return Result.error("Cannot create production plans due to insufficient inventory or equipment issues.");
        }
    }


    @GetMapping
    public Result getAllProductionPlans() {
        List<ProductionPlan> allPlans = productionPlanService.getAllProductionPlans();  // 查询所有生产计划
        if (allPlans.isEmpty()) {
            return Result.error("No production plans found.");
        } else {
            return Result.success(allPlans);
        }
    }


    @GetMapping("/order/{orderId}")
    public Result getProductionPlanByOrderId(@PathVariable Long orderId) {
        ProductionPlan plan = productionPlanService.getProductionPlanByOrderId(orderId);  // 根据订单ID查询生产计划
        if (plan == null) {
            return Result.error("No production plan found for the given order ID.");
        } else {
            return Result.success(plan);
        }
    }


    @PutMapping("/{planId}")
    public Result updateProductionPlanStatus(@PathVariable Integer planId, @RequestParam String status) {
        productionPlanService.updateProductionPlanStatus(planId, status);  // 更新生产计划状态
        return Result.success("Production plan status updated successfully.");
    }


    @DeleteMapping("/{planId}")
    public Result deleteProductionPlan(@PathVariable Integer planId) {
        productionPlanService.deleteProductionPlan(planId);  // 删除生产计划
        return Result.success("Production plan deleted successfully.");
    }
}
