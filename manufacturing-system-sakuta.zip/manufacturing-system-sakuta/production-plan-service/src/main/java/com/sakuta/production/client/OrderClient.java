package com.sakuta.production.client;

import com.sakuta.production.model.Order;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "order-service", url = "http://localhost:9091")
public interface OrderClient {

    @GetMapping("/orders")
    List<Order> getAllOrders();
}
