package com.sakuta.production.mapper;

import com.sakuta.production.model.ProductionPlan;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ProductionPlanMapper {

    @Insert("INSERT INTO production_plans (order_id, plan_date, status, priority) " +
            "VALUES (#{orderId}, #{planDate}, #{status}, #{priority})")
    @Options(useGeneratedKeys = true, keyProperty = "planId")
    void insertProductionPlan(ProductionPlan plan);

    @Select("SELECT * FROM production_plans WHERE order_id = #{orderId}")
    List<ProductionPlan> selectPlansByOrderId(Long orderId);  // 根据订单ID查询生产计划

    @Select("SELECT * FROM production_plans")
    List<ProductionPlan> selectAllPlans();  // 查询所有生产计划

    @Update("UPDATE production_plans SET status = #{status} WHERE plan_id = #{planId}")
    void updatePlanStatus(Integer planId, String status);  // 更新生产计划状态


    @Delete("DELETE FROM production_plans WHERE plan_id = #{planId}")
    void deleteProductionPlan(Integer planId);  // 根据生产计划ID删除生产计划
}
