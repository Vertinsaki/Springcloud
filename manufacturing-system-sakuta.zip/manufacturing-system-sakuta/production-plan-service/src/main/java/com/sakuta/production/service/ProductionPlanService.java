package com.sakuta.production.service;

import com.sakuta.production.model.ProductionPlan;
import java.util.List;

public interface ProductionPlanService {

    boolean checkProductionReadiness();

    void createPlansForAllOrders();


    List<ProductionPlan> getAllProductionPlans();

    ProductionPlan getProductionPlanByOrderId(Long orderId);

    void updateProductionPlanStatus(Integer planId, String status);

    void deleteProductionPlan(Integer planId);


}
