package com.sakuta.order.repository;

import com.sakuta.order.model.Order;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface OrderMapper {

    @Insert("INSERT INTO orders (customer_name, order_amount, order_date) VALUES (#{customerName}, #{orderAmount}, #{orderDate})")
    @Options(useGeneratedKeys = true, keyProperty = "orderId")
    void insertOrder(Order order);

    @Update("UPDATE orders SET customer_name = #{customerName}, order_amount = #{orderAmount}, order_date = #{orderDate} WHERE order_id = #{orderId}")
    void updateOrder(Order order);

    @Select("SELECT * FROM orders WHERE order_id = #{orderId}")
    Order selectOrderById(Long orderId);


    @Select("SELECT * FROM orders")
    List<Order> selectAllOrders();

}
