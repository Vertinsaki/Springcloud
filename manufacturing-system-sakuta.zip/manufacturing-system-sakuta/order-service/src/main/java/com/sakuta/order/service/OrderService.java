package com.sakuta.order.service;

import com.sakuta.order.model.Order;

import java.util.List;

public interface OrderService {

    void createOrder(Order order);

    void updateOrder(Long orderId, Order order);

    Order getOrderById(Long orderId);


    List<Order> getAllOrders();
}
