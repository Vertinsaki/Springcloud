package com.sakuta.order.controller;

import com.sakuta.order.model.Order;
import com.sakuta.order.model.Result;
import com.sakuta.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public Result createOrder(@RequestBody Order order) {
        orderService.createOrder(order);
        return Result.success();
    }

    @PutMapping("/{id}")
    public Result updateOrder(@PathVariable Long id, @RequestBody Order order) {
        orderService.updateOrder(id, order);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result getOrder(@PathVariable Long id) {
       Order order =orderService.getOrderById(id);
       return Result.success(order);
    }


    @GetMapping
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }


}
