package com.sakuta.order.service.impl;

import com.sakuta.order.model.Order;
import com.sakuta.order.repository.OrderMapper;
import com.sakuta.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderMapper orderMapper;

    @Autowired
    public OrderServiceImpl(OrderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    @Override
    public void createOrder(Order order) {
        orderMapper.insertOrder(order);
    }

    @Override
    public void updateOrder(Long orderId, Order order) {
        order.setOrderId(orderId);
        orderMapper.updateOrder(order);
    }

    @Override
    public Order getOrderById(Long orderId) {
        return orderMapper.selectOrderById(orderId);
    }


    @Override
    public List<Order> getAllOrders() {
        return orderMapper.selectAllOrders();
    }


}
