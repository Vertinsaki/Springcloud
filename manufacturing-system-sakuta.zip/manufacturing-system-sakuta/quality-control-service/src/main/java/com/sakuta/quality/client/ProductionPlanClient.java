package com.sakuta.quality.client;

import com.sakuta.quality.model.ProductionPlan;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "production-plan-service", url = "http://localhost:9092")
public interface ProductionPlanClient {
    @GetMapping("/production-plans")
    List<ProductionPlan> getAllProductionPlans();
}
