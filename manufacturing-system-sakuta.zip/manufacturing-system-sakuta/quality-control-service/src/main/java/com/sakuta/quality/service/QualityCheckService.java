package com.sakuta.quality.service;

public interface QualityCheckService {
    void performQualityChecks();  // 执行质量检查
}
