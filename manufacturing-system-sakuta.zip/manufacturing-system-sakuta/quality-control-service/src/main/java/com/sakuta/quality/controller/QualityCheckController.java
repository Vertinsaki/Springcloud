package com.sakuta.quality.controller;

import com.sakuta.quality.service.QualityCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/quality-checks")
public class QualityCheckController {

    @Autowired
    private QualityCheckService qualityCheckService;

    @PostMapping("/perform")
    public String performQualityChecks() {
        qualityCheckService.performQualityChecks();
        return "Quality checks performed successfully and results saved.";
    }
}
