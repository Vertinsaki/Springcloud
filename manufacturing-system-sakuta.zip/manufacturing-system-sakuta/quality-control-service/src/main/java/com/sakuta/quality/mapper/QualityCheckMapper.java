package com.sakuta.quality.mapper;

import com.sakuta.quality.model.QualityCheck;
import org.apache.ibatis.annotations.*;

@Mapper
public interface QualityCheckMapper {

    @Insert("INSERT INTO quality_checks (order_id, is_quality_good, check_date) " +
            "VALUES (#{orderId}, #{isQualityGood}, #{checkDate})")
    @Options(useGeneratedKeys = true, keyProperty = "checkId")
    void insertQualityCheck(QualityCheck qualityCheck);
}
