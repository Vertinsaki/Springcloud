package com.sakuta.quality.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "equipment-service", url = "http://localhost:9094")
public interface EquipmentClient {
    @GetMapping("/equipment/status")
    boolean checkEquipmentStatus();
}
