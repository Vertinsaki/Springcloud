package com.sakuta.quality.service.impl;

import com.sakuta.quality.client.EquipmentClient;
import com.sakuta.quality.client.InventoryClient;
import com.sakuta.quality.client.ProductionPlanClient;
import com.sakuta.quality.mapper.QualityCheckMapper;
import com.sakuta.quality.model.ProductionPlan;
import com.sakuta.quality.model.QualityCheck;
import com.sakuta.quality.service.QualityCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class QualityCheckServiceImpl implements QualityCheckService {

    @Autowired
    private ProductionPlanClient productionPlanClient;

    @Autowired
    private InventoryClient inventoryClient;

    @Autowired
    private EquipmentClient equipmentClient;

    @Autowired
    private QualityCheckMapper qualityCheckMapper;

    @Override
    public void performQualityChecks() {

        List<ProductionPlan> plans = productionPlanClient.getAllProductionPlans();

        boolean isInventoryGood = inventoryClient.checkInventoryStatus();
        boolean isEquipmentGood = equipmentClient.checkEquipmentStatus();

        for (ProductionPlan plan : plans) {
            QualityCheck qualityCheck = new QualityCheck();
            qualityCheck.setOrderId(plan.getOrderId());
            qualityCheck.setCheckDate(LocalDateTime.now());
            qualityCheck.setIsQualityGood(isInventoryGood && isEquipmentGood);

            qualityCheckMapper.insertQualityCheck(qualityCheck);
        }
    }
}
