package com.sakuta.quality.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class QualityCheck {
    private Integer checkId;

    private Long orderId;

    private Boolean isQualityGood;

    private LocalDateTime checkDate;
}
